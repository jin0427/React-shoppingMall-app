export default function DetailPage() {
  return (
    <>
      <div>자세한 상품 정보</div>
    </>
  );
}
