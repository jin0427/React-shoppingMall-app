export default function CartListPage() {
  return <div>장바구니</div>;
}
